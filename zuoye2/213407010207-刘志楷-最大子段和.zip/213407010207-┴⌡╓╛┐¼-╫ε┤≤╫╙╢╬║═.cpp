#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int maxSubArraySum(vector<int>& nums) {
    int max_sum = 0;
    int current_sum = 0;

    for (int num : nums) {
        current_sum = max(0, current_sum + num);
        max_sum = max(max_sum, current_sum);
    }

    return max_sum;
}

int main() {
    vector<int> nums = { -2, 11, -4, 13, -5, -2 };
    int result = maxSubArraySum(nums);
    cout << "����Ӷκ�Ϊ: " << result << endl;
    return 0;
}
